<?php
namespace PayPal\PayPalAPI;

use PayPal\EBLBaseComponents\AbstractResponseType;

/**
 *
 */
class GetRecurringPaymentsProfileDetailsResponseType extends AbstractResponseType
{

    /**
     *
     * @access    public
     * @namespace ebl
     * @var \PayPal\EBLBaseComponents\GetRecurringPaymentsProfileDetailsResponseDetailsType
     */
    public $GetRecurringPaymentsProfileDetailsResponseDetails;

}
