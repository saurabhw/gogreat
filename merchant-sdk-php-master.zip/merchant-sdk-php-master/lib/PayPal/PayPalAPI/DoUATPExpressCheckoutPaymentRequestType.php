<?php
namespace PayPal\PayPalAPI;

/**
 *
 */
class DoUATPExpressCheckoutPaymentRequestType extends DoExpressCheckoutPaymentRequestType
{

}
