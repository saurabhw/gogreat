<?php
namespace PayPal\PayPalAPI;

use PayPal\EBLBaseComponents\AbstractResponseType;

/**
 * The status of the update call, Success/Failure. Character
 * length and limitations: 20 single-byte characters
 */
class UpdateAccessPermissionsResponseType extends AbstractResponseType
{

    /**
     * The status of the update call, Success/Failure. Character
     * length and limitations: 20 single-byte characters
     * @access    public
     * @namespace ns
     * @var string
     */
    public $Status;

}
