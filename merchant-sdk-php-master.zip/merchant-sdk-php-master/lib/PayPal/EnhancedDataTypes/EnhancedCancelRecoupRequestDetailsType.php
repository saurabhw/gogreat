<?php
namespace PayPal\EnhancedDataTypes;

use PayPal\Core\PPXmlMessage;

/**
 *
 */
class EnhancedCancelRecoupRequestDetailsType
  extends PPXmlMessage
{

}
