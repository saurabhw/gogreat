<?php
namespace PayPal\EBLBaseComponents;

use PayPal\Core\PPXmlMessage;

/**
 *
 */
class PersonNameType
  extends PPXmlMessage
{

    /**
     *
     * @access    public
     * @namespace ebl
     * @var string
     */
    public $Salutation;

    /**
     *
     * @access    public
     * @namespace ebl
     * @var string
     */
    public $FirstName;

    /**
     *
     * @access    public
     * @namespace ebl
     * @var string
     */
    public $MiddleName;

    /**
     *
     * @access    public
     * @namespace ebl
     * @var string
     */
    public $LastName;

    /**
     *
     * @access    public
     * @namespace ebl
     * @var string
     */
    public $Suffix;

}
