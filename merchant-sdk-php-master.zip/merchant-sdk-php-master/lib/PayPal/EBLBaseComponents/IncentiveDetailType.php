<?php
namespace PayPal\EBLBaseComponents;

use PayPal\Core\PPXmlMessage;

/**
 *
 */
class IncentiveDetailType
  extends PPXmlMessage
{

    /**
     *
     * @access    public
     * @namespace ebl
     * @var string
     */
    public $RedemptionCode;

    /**
     *
     * @access    public
     * @namespace ebl
     * @var string
     */
    public $DisplayCode;

    /**
     *
     * @access    public
     * @namespace ebl
     * @var string
     */
    public $ProgramId;

    /**
     *
     * @access    public
     * @namespace ebl
     * @var string
     */
    public $IncentiveType;

    /**
     *
     * @access    public
     * @namespace ebl
     * @var string
     */
    public $IncentiveDescription;

    /**
     *
     * @array
     * @access    public
     * @namespace ebl
     * @var \PayPal\EBLBaseComponents\IncentiveAppliedToType
     */
    public $AppliedTo;

    /**
     *
     * @access    public
     * @namespace ebl
     * @var string
     */
    public $Status;

    /**
     *
     * @access    public
     * @namespace ebl
     * @var string
     */
    public $ErrorCode;

}
