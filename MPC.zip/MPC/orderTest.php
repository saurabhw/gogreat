<?php 
  
?>
<html>
<head>
</head>
<body>
<h1>Oder Test</h1>
<br>
<form method="post" action="notifyTest.php">
<input type="text" name="order">
<input type="submit" name="submit" value="test">
</form>
</body>
</html>