<form action="ZTQ_DBtest.php" method="post">
Date: <input type="text" name="thedate" /><br>
Format: Dec12,2011<br>
<input type="submit" />