<form action="DBtest.php" method="post">
Date: <input type="text" name="thedate" /><br>
Format: Dec 12,2011<br>
<input type="submit" />